import 'package:flutter/material.dart';

class CurrentUsage extends StatelessWidget {
  const CurrentUsage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Center(
        child: Text("CurrentUsage_page"),
      ),
    );
  }
}