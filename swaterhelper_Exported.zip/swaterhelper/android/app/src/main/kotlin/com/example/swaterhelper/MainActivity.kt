package com.example.swaterhelper

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
